
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class PlayerSelection {
    public static void main(String[] args) {

        int playerAge = 0;
        int typeOfPlayer = 0;
        int stat = 0;


        ArrayList<String> players = new ArrayList<>();   //  array list of players
        players.add("Aravinda de Silva");
        players.add("Tillakaratne Dilshan");
        players.add("Mahela Jayawardene");
        players.add("Arjuna Ranatunga");
        players.add("Muttiah Muralitharan");
        players.add("Kumar Sangakkara");
        players.add("Chaminda Vaas");
        players.add("Sanath Jayasuriya");
        players.add("Lasith Malinga");
        players.add("Lahiru Thirimanne");
        players.add("Nuwan Kulasekara");


        Player Acc1 = new Player(playerAge, typeOfPlayer, stat, players);  // creating objects and calling the constructor

        System.out.println(players);


        String count = null;

        // using do while loop to get inputs

        do {                                                                              //Menu options
            System.out.println("To Add Player                       : press A");
            System.out.println("To Get Balling or Batting average   : press B");
            System.out.println("To Get Player Details               : press C");
            System.out.println("To Get Best Performance             : press D");
            System.out.println("To Get Player Type                  : press E");
            System.out.println("To Get Physical Test Result         : press F");
            System.out.println("To View All Players                 : press V");
            System.out.println("To Exit                             : press Q");

            Scanner input = new Scanner(System.in);

            System.out.print("Press Task Letter : ");
            String task_letter = input.next().toUpperCase();

            switch (task_letter) {                                 // switch case for get menu option inputs
                case "A":

                    Acc1.AddPlayer();
                    break;
                case "B":

                    Acc1.GetAvg();
                    break;
                case "C":

                    Acc1.GetPlayerDetails();
                    break;
                case "D":

                    Acc1.GetBestPerformance();
                    break;
                case "E":

                    Acc1.GetPlayerType();
                    break;
                case "F":

                    Acc1.GetPhysicalTestResult();
                    break;
                case "V":

                    Player.ViewAllPlayers();
                    break;
                case "Q":

                    count = "Q";
            }
        } while (!Objects.equals(count, "Q")); // end of the do while loop
        System.out.println("Thank you!");
    }
}
