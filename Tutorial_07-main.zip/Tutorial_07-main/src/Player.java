
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class Player {

    private static double totalWickets;                                   // instance variables
    private static double totalBalls;
    private String playerName;
    private int playerAge;
    private int typeOfPlayer;
    private int stat;
    private static ArrayList<String> players;

    public Player(int age, int type, int stat, ArrayList<String> players) { // constructor

        Player.players = players;  // converting instance variables to local variables
        this.playerAge = age;
        this.typeOfPlayer = type;
        this.stat = stat;
    }

    public static void setTotalBalls(double totalBalls) { // set total ball method
        Player.totalBalls = totalBalls;
    }


    @Override
    public String toString() {   //converting to string AND overriding it
        return "Player{" +
                "name='" + playerName+ '\'' +
                ", age=" + playerAge+
                ", type=" + typeOfPlayer +
                ", stat=" + stat +
                '}';
    }

    @Override //checking for equals
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Player player)) return false;
        return getAge() == player.getAge() && getType() == player.getType() && getStat() == player.getStat() && getName().equals(player.getName());
    }

    @Override //creating the hashcode
    public int hashCode() {
        return Objects.hash(getName(), getAge(), getType(), getStat());
    }


    public String getName() {
        return playerName;
    }

    public void setName(String name) {
        this.playerName = name;
    }

    public int getAge() {
        return playerAge;
    }

    public void setAge(int age) {
        this.playerAge = age;
    }

    public int getType() {
        return typeOfPlayer;
    }

    public void setType(int type) {
        this.typeOfPlayer = type;
    }

    public int getStat() {
        return stat;
    }

    public void setStat(int stat) {
        this.stat = stat;
    }

    public static ArrayList<String> getPlayers() {
        return players;
    }

    public static void setPlayers(ArrayList<String> players) {
        Player.players = players;
    }

    public static double getTotalWickets() {
        return totalWickets;
    }

    public static void setTotalWickets(double totalWickets) {
        Player.totalWickets = totalWickets;
    }


    public Player(String name, int age, int type, int stat) {
        this.playerName = name;
        this.playerAge = age;
        this.typeOfPlayer = type;
        this.stat = stat;
    }

    public void AddPlayer() {   //add player method
        Scanner input = new Scanner(System.in);
        System.out.println();

        System.out.print("\nEnter Player's Name : ");
        playerName = input.nextLine();

        System.out.print("\nEnter player's Age : ");
        playerAge = input.nextInt();

        playerType();
        System.out.print("\nEnter Player Type : ");
        typeOfPlayer = input.nextInt();

        System.out.print("\nEnter Player's statistics : ");
        stat = input.nextInt();
    }

    private void playerType() {   // player type method for repeating
        System.out.println("============================");
        System.out.println("|    SELECT PLAYER TYPE    |");
        System.out.println("============================");
        System.out.println("|      1. Spin Bowler      |");
        System.out.println("|      2. Seam Bowler      |");
        System.out.println("|      3. Batsman          |");
        System.out.println("|      4. Keeper           |");
        System.out.println("============================");
    }

    public void GetPlayerDetails() {      // get player details
        System.out.println("Player Name : " + playerName);
        System.out.println("Age of Player : " + playerAge);
        System.out.println("Player Type : " + typeOfPlayer);
        System.out.println("Player Statistics : " + stat);
    }

    public void GetPlayerType() {     // get player type
        playerType();
        Scanner input = new Scanner(System.in);
        System.out.print("Please select the type of player : ");
        int typeOfPlayer = input.nextInt();
    }

    public void GetPhysicalTestResult() {   // get physical test results

        Scanner input = new Scanner(System.in);
        System.out.print("\nPlease Enter your physicalResult : ");
        int physicalResult = input.nextInt();
        System.out.println();


// grading of players using if else
        if ((physicalResult > 80) && (physicalResult <= 100)) {
            System.out.println("Your physical test results : A");
        } else if ((physicalResult > 60) && (physicalResult <= 80)) {
            System.out.println("Your physical test results : B");
        } else if ((physicalResult > 50) && (physicalResult <= 60)) {
            System.out.println("Your physical test results : C");
        } else if ((physicalResult > 45) && (physicalResult <= 50)) {
            System.out.println("Your physical test results : D");
        } else if ((physicalResult > 25) && (physicalResult <= 45)) {
            System.out.println("Your physical test results : E");
        } else if ((physicalResult >= 0) && (physicalResult <= 25)) {
            System.out.println("Your physical test results : F");
        } else {
            System.out.println("Please \nEnter a physicalResult in the range 0-100");
        }
    }

    public void GetBestPerformance() {  // get best performance method
        Scanner input = new Scanner(System.in);
        System.out.print(playerName + "'s best performance in the past 15 matches : ");
        int bestPerformance = input.nextInt();

        GetPlayerType();            //  switch case for get player type method
        switch (typeOfPlayer) {             // Not Recommended!
            case 1:

            case 2: {
                System.out.println("player with best bowling performance is Arjuna Ranathunga");
                System.out.println("player with best bowling performance is Muttiah Muralitharan");
            }
            break;

            case 3: {
                System.out.println("Best batter is Kumar Sangakkara");
                System.out.println("Best batter is Mahela Jayawardene");
            }
            break;

            case 4: {
                System.out.println("Best batter is Tilakarathne Dilshan");
            }
        }
    }


    public static void ViewAllPlayers () // view all players method
    {
        for (String item : players) {
            System.out.println(item);
        }
    }

    public void GetAvg ()  // get average value method
    {
        Scanner input = new Scanner(System.in);

        System.out.print("Please enter the batting or bowling average of " + playerName + " : ");
        double avg = input.nextDouble();
        GetPlayerType();


        switch (typeOfPlayer) {   // switch case for getting average method

            case 1:
            case 2:
                double battingAvg = totalWickets / 15;
                System.out.println("batting average:" + battingAvg);
                break;


            case 3:
                double bowlingAvg = totalBalls / 15;
                System.out.println("bowling average:" + bowlingAvg);
                throw new IllegalStateException("Unexpected value: " + typeOfPlayer);

            default:
                throw new IllegalStateException("Unexpected value: " + typeOfPlayer);
        }
    }
}

